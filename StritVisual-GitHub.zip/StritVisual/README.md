# Strit Visual — independent Fabric project

This is the first implementation milestone for an original client-side visual mod. It does **not** copy Soup Visuals code or assets. The supplied Soup Visuals archive's `SOUP-1.0` license restricts use, modification, copying, and derivative works without prior written permission, so this project is independently authored.

## Current implementation
- Fabric client entrypoint and `Strit Visual` mod ID.
- Right Shift opens a compact dark-themed menu (keyboard binding can be changed in Minecraft Controls).
- Watermark and FPS HUD overlay with violet accent.
- Local JSON config at `.minecraft/config/stritvisual.json` with safe fallback defaults.
- Menu toggles for watermark/FPS are implemented; particles and custom crosshair toggles are placeholders and are explicitly labelled planned.
- No telemetry, account access, hidden downloads, or network code.

## Target setup
- Minecraft Java Edition 1.21.11
- Fabric Loader 0.18.4+
- Fabric API 0.141.3+1.21.11
- Java 21+

## Build
Install Gradle 8.14+ (or use a Gradle wrapper generated in a trusted local environment), then run:

```sh
gradle build
```

The JAR should be created under `build/libs/`. This workspace did not have Gradle installed and the build has **not** been run here, so this source project is not yet a verified build and no ready-to-install JAR is claimed.

## Install after building
Copy the built `StritVisual-0.1.0.jar` into the instance's `mods` folder together with Fabric API. Use a separate test instance first. Android launcher compatibility has not yet been tested.

## Verification status
- Source/project files created: yes
- Soup Visuals license inspected: yes (`SOUP-1.0` prohibits reuse without written permission)
- Compilation: not run (Gradle unavailable in the environment)
- Minecraft launch/runtime test: not run
- Android/MJLauncher/Zalith test: not run
