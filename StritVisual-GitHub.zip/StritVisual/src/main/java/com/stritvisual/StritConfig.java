package com.stritvisual;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Small local-only config. No telemetry or network access. */
public final class StritConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("stritvisual.json");

    public static boolean watermark = true;
    public static boolean showFps = true;
    public static boolean particles = true;
    public static boolean crosshair = true;
    public static int accentColor = 0xFF9B72FF;

    private StritConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) { save(); return; }
        try {
            ConfigData d = GSON.fromJson(Files.readString(FILE), ConfigData.class);
            if (d != null) {
                watermark = d.watermark;
                showFps = d.showFps;
                particles = d.particles;
                crosshair = d.crosshair;
                accentColor = d.accentColor;
            }
        } catch (Exception ignored) {
            // Keep safe defaults if config is malformed; don't crash game startup.
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            ConfigData d = new ConfigData();
            d.watermark = watermark; d.showFps = showFps; d.particles = particles;
            d.crosshair = crosshair; d.accentColor = accentColor;
            Files.writeString(FILE, GSON.toJson(d));
        } catch (IOException ignored) { /* Config failure must not crash the client. */ }
    }

    private static final class ConfigData {
        boolean watermark = true;
        boolean showFps = true;
        boolean particles = true;
        boolean crosshair = true;
        int accentColor = 0xFF9B72FF;
    }
}
