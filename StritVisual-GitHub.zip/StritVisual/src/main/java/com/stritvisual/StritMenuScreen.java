package com.stritvisual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class StritMenuScreen extends Screen {
    private int panelX, panelY, panelW, panelH;

    public StritMenuScreen() { super(Text.literal("Strit Visual")); }

    @Override
    protected void init() {
        panelW = Math.min(360, this.width - 24);
        panelH = Math.min(280, this.height - 24);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        int bx = panelX + 20, bw = panelW - 40, bh = 22, gap = 7, by = panelY + 58;

        addDrawableChild(ButtonWidget.builder(toggleLabel("Watermark", StritConfig.watermark), b -> {
            StritConfig.watermark = !StritConfig.watermark; b.setMessage(toggleLabel("Watermark", StritConfig.watermark)); StritConfig.save();
        }).dimensions(bx, by, bw, bh).build());
        by += bh + gap;
        addDrawableChild(ButtonWidget.builder(toggleLabel("FPS counter", StritConfig.showFps), b -> {
            StritConfig.showFps = !StritConfig.showFps; b.setMessage(toggleLabel("FPS counter", StritConfig.showFps)); StritConfig.save();
        }).dimensions(bx, by, bw, bh).build());
        by += bh + gap;
        addDrawableChild(ButtonWidget.builder(toggleLabel("Particles (planned)", StritConfig.particles), b -> {
            StritConfig.particles = !StritConfig.particles; b.setMessage(toggleLabel("Particles (planned)", StritConfig.particles)); StritConfig.save();
        }).dimensions(bx, by, bw, bh).build());
        by += bh + gap;
        addDrawableChild(ButtonWidget.builder(toggleLabel("Custom crosshair (planned)", StritConfig.crosshair), b -> {
            StritConfig.crosshair = !StritConfig.crosshair; b.setMessage(toggleLabel("Custom crosshair (planned)", StritConfig.crosshair)); StritConfig.save();
        }).dimensions(bx, by, bw, bh).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(bx, panelY + panelH - 34, bw, 22).build());
    }

    private static Text toggleLabel(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF0121420);
        context.fill(panelX, panelY, panelX + panelW, panelY + 3, StritConfig.accentColor);
        context.drawText(textRenderer, Text.literal("STRIT VISUAL"), panelX + 20, panelY + 17, 0xFFFFFFFF, false);
        context.drawText(textRenderer, Text.literal("PvP visuals • client settings"), panelX + 20, panelY + 34, 0xFFB7BBD0, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
}
