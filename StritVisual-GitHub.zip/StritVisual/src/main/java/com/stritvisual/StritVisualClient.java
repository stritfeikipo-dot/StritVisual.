package com.stritvisual;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class StritVisualClient implements ClientModInitializer {
    public static final String MOD_ID = "stritvisual";
    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        StritConfig.load();
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.stritvisual.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.category.stritvisual"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new StritMenuScreen());
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden || !StritConfig.watermark) return;
            int x = 8, y = 8;
            drawContext.fill(x - 4, y - 3, x + 112, y + 17, 0xA9161722);
            drawContext.fill(x - 4, y - 3, x - 1, y + 17, StritConfig.accentColor);
            drawContext.drawText(client.textRenderer, Text.literal("STRIT VISUAL"), x + 3, y, 0xFFFFFFFF, false);
            if (StritConfig.showFps) {
                String fps = client.getCurrentFps() + " FPS";
                drawContext.drawText(client.textRenderer, Text.literal(fps), x + 3, y + 9, 0xFFBFC4D8, false);
            }
        });
    }
}
